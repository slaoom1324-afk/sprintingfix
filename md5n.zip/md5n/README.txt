md5n - Fabric client mod (Minecraft Java 1.21.4)

البناء: ارفع md5n.zip لمستودع GitHub (مع ملف .github/workflows/build.yml) وحمّل md5n-jar من تبويب Actions.
أو على ويندوز: فك الزيب وشغّل build.bat (قد يحجبه Smart App Control).

فتح القائمة: Right Shift + Space (تغيّره من Theme ← Menu Key)

القائمة:
- لوحات بالفئات (Combat / Movement / Visual / Client)، اسحب الهيدر تحرّكها، وكليك عليه يطويها
- كليك يسار على المود: تشغيل/إطفاء (مع صوت)
- كليك يمين: فتح/إغلاق إعدادات المود
- كليك وسط على المود: ربط مفتاح بتشغيله
- كليك وسط على أي خيار ON/OFF أو Mode: ربط مفتاح يبدّله
- اكتب مباشرة في الشاشة للبحث عن مود
- الإعدادات والمفاتيح تنحفظ تلقائياً في config/md5n.json

ElytraTarget: اضغط مفتاح القفل (الافتراضي G) وأنت تطير ليقفل على أقرب هدف لاتجاه نظرك،
وبعدها يلحقه ويطلق الصواريخ تلقائياً. اضغط G مرة ثانية لإلغاء القفل.

لإضافة مود: انسخ Sprint.java كقالب، واستخدم bool(...) و num(...) و mode(...) و keybind(...)، وسجّله في ModuleManager.

ستايل Glass (الافتراضي): لوحات زجاجية بزوايا مدورة وتوهج، وHUD بحبوب (إحداثيات / اسم + FPS + سيرفر + ساعة / سرعة مع رسم بياني).
تبدّل بينه وبين Classic من Theme ← Style، والألوان من Theme ← Theme (Emerald هو الأخضر الجديد).

PlayerAlert (Visual): ينبّهك بصوت ورسالة فوق الهوت بار لما يقرب منك لاعب (المسافة من الإعدادات)، مع اسمه ومسافته واتجاهه (N/E/S/W).

VFX ← Sky: يغيّر لون السماء (الأوفرورلد). 10 ستايلات: 5 ثابتة (Sunset, Twilight, Blood, Emerald, Void)
و5 متحركة (Rainbow, Aurora, Pulse, Lava, Dream). الخيارات: Speed و Brightness و Day/Night Blend.
(هذا المود يستخدم Mixin: ملف md5n.mixins.json)

VFX ← Kill VFX: تأثيرات جسيمات لما تقتل لاعب (10 أنواع + Random): Burst, Soul Rise, Lightning, Totem, Ring Wave,
Meteor, Portal, Hearts, Cherry, Galaxy. مفتاح Test Key (الافتراضي J) يعرض التأثير قدامك للتجربة.
VFX ← Ambiance: 12 تأثير جوّي تشغّلهم/تطفيهم من الإعدادات: Fireflies, Sparkles, Snowfall, Cherry Petals, Embers,
Ash Fall, Spores, Soul Wisps, Magic Glyphs, Mist, Dragon Breath, Void Dust.
(الجسيمات تظهر فقط لو إعداد Particles في ماينكرافت مو Minimal)

Cosmetic (7 مودات، كل واحد 10 ستايلات): Hat, Aura, Trail, Back, Jump VFX, Cape, Wing.
- كلها مبنية من جسيمات حولك وتظهر لك أنت بس. اضغط F5 (منظور ثالث) عشان تشوفها.
- الألوان مربوطة بـ Theme: لون الواجهة (وRainbow Accent) هو لون الكوزمتك. تطفي Theme ← Sync Cosmetics لو تبي لون مختلف لكل واحد.
- خيار VFX في كل كوزمتك يضيف تأثيرات فوقه (Sparkle, Glow, Flame, Soul, Magic, Electric, Snow, Petals).
