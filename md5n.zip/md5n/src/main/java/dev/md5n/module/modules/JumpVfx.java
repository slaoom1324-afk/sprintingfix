package dev.md5n.module.modules;

import dev.md5n.setting.BoolSetting;
import dev.md5n.util.Colors;
import dev.md5n.util.Fx;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class JumpVfx extends Cosmetic {
    private final BoolSetting landing = bool("Land Effect", true, "Also play the effect when you land from a fall");

    private static final class Active {
        double x, y, z, fx, fz, rx, rz;
        int age;
        String style;
    }

    private final List<Active> active = new ArrayList<>();
    private boolean wasOnGround = true;
    private double peakY;

    public JumpVfx() {
        super("Jump VFX", "Particle effects when you jump (press F5 to see)",
                new String[]{"Ring Burst", "Spiral Up", "Wings Pop", "Shockwave", "Stars", "Spring", "Lightning", "Double Ring", "Burst", "Ripple"});
    }

    // كل شي يصير داخل onTick
    @Override
    protected void emit(String styleName) {}

    @Override
    protected void onDisable() {
        active.clear();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        prepare();

        boolean onGround = mc.player.isOnGround();
        if (!onGround) {
            peakY = Math.max(peakY, ay);
        } else {
            if (!wasOnGround && landing.get() && peakY - ay >= 1.5) begin();
            peakY = ay;
        }
        if (wasOnGround && !onGround && pvy > 0.05) {
            begin();
            peakY = ay;
        }
        wasOnGround = onGround;

        Iterator<Active> it = active.iterator();
        while (it.hasNext()) {
            Active a = it.next();
            if (step(a)) it.remove();
            else a.age++;
        }
    }

    private void begin() {
        if (!firstPerson.get() && mc.options.getPerspective().isFirstPerson()) return;
        Active a = new Active();
        a.x = ax;
        a.y = ay;
        a.z = az;
        a.fx = fx;
        a.fz = fz;
        a.rx = rx;
        a.rz = rz;
        a.style = style.get();
        active.add(a);
    }

    private void ring(Active a, double r, double y, int pts, int rgb, double out) {
        for (int i = 0; i < pts; i++) {
            double ang = i * TAU / pts;
            spawnWorld(a.x + Math.cos(ang) * r, a.y + y, a.z + Math.sin(ang) * r, rgb,
                    Math.cos(ang) * out, 0.0, Math.sin(ang) * out);
        }
    }

    private void local(Active a, double lx, double ly, double lz, int rgb, double vx, double vy, double vz) {
        spawnWorld(a.x + a.rx * lx + a.fx * lz, a.y + ly, a.z + a.rz * lx + a.fz * lz, rgb, vx, vy, vz);
    }

    /** يرجع true لما يخلص التأثير. */
    private boolean step(Active a) {
        int age = a.age;
        double sz = size.get();
        int c = col(age / 20.0);

        switch (a.style) {
            case "Spiral Up": {
                if (age < 14) {
                    for (int k = 0; k < 2; k++) {
                        double ang = age * 0.7 + k * Math.PI;
                        spawnWorld(a.x + Math.cos(ang) * 0.5 * sz, a.y + age * 0.12, a.z + Math.sin(ang) * 0.5 * sz,
                                c, 0.0, 0.02, 0.0);
                    }
                }
                return age >= 14;
            }
            case "Wings Pop": {
                if (age < 10) {
                    for (int side = -1; side <= 1; side += 2) {
                        for (int j = 0; j <= 5; j++) {
                            double f = j / 5.0;
                            double lx = side * (0.15 + f * age * 0.09) * sz;
                            double ly = 0.9 + f * 0.6 * (age / 10.0);
                            local(a, lx, ly, -0.15, col(f), 0.0, 0.01, 0.0);
                        }
                    }
                }
                return age >= 10;
            }
            case "Shockwave": {
                if (age < 6) {
                    ring(a, (0.2 + age * 0.3) * sz, 0.1, 26, c, 0.03);
                    int k = n(4);
                    for (int i = 0; i < k; i++) {
                        double ang = rnd() * TAU;
                        Fx.puff(a.x + Math.cos(ang) * age * 0.3, a.y + 0.1, a.z + Math.sin(ang) * age * 0.3,
                                Math.cos(ang) * 0.05, 0.02, Math.sin(ang) * 0.05);
                    }
                }
                return age >= 6;
            }
            case "Stars": {
                if (age == 0) {
                    int k = n(18);
                    for (int i = 0; i < k; i++) {
                        spawnWorld(a.x, a.y + 0.3, a.z, Colors.lerp(c, 0xFFFFFF, 0.5),
                                spread(0.1), 0.1 + rnd() * 0.15, spread(0.1));
                    }
                }
                return age >= 2;
            }
            case "Spring": {
                if (age < 10) {
                    double x0 = ((age % 2 == 0) ? 1.0 : -1.0) * 0.25 * sz;
                    double x1 = -x0;
                    for (int i = 0; i < 4; i++) {
                        double f = i / 3.0;
                        local(a, x0 + (x1 - x0) * f, (age + f) * 0.18, 0.0, c, 0.0, 0.0, 0.0);
                    }
                }
                return age >= 12;
            }
            case "Lightning": {
                if (age < 4) {
                    double jx = 0.0;
                    double jz = 0.0;
                    for (double hh = 0.0; hh <= 3.0; hh += 0.22) {
                        jx += spread(0.12);
                        jz += spread(0.12);
                        spawnWorld(a.x + jx, a.y + hh, a.z + jz, Colors.lerp(c, 0xFFFFFF, 0.6), 0.0, 0.0, 0.0);
                    }
                }
                return age >= 4;
            }
            case "Double Ring": {
                if (age < 8) ring(a, (0.2 + age * 0.2) * sz, 0.1, 16, c, 0.02);
                if (age >= 3 && age < 11) {
                    ring(a, (0.2 + (age - 3) * 0.2) * sz, 0.25, 16, Colors.lerp(c, 0xFFFFFF, 0.4), 0.02);
                }
                return age >= 11;
            }
            case "Burst": {
                if (age == 0) {
                    int k = n(30);
                    for (int i = 0; i < k; i++) {
                        double ang = rnd() * TAU;
                        double sp = 0.2 + rnd() * 0.2;
                        spawnWorld(a.x, a.y + 0.2, a.z, c, Math.cos(ang) * sp, 0.05 + rnd() * 0.1, Math.sin(ang) * sp);
                    }
                }
                return age >= 2;
            }
            case "Ripple": {
                for (int start = 0; start <= 8; start += 4) {
                    int ra = age - start;
                    if (ra >= 0 && ra < 10) ring(a, (0.2 + ra * 0.12) * sz, 0.05, 14, c, 0.0);
                }
                return age >= 18;
            }
            default: {
                // Ring Burst
                if (age < 8) ring(a, (0.2 + age * 0.18) * sz, 0.1, 18, c, 0.02);
                return age >= 8;
            }
        }
    }
}
