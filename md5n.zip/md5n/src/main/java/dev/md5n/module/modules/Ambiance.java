package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.NumSetting;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

import java.util.concurrent.ThreadLocalRandom;

public class Ambiance extends Module {
    private final NumSetting radius = num("Radius", 12, 4, 24, 1, "How far around you the effects spawn");
    private final NumSetting intensity = num("Intensity", 1.0, 0.2, 3.0, 0.1, "How many particles spawn");
    private final BoolSetting outdoorsOnly = bool("Outdoors Only", true, "Falling effects only when you can see the sky");

    private final BoolSetting fireflies = bool("Fireflies", true, "Glowing dots drifting near the ground");
    private final BoolSetting sparkles = bool("Sparkles", true, "Slow white stardust floating upward");
    private final BoolSetting snow = bool("Snowfall", false, "Gentle snow falling around you");
    private final BoolSetting petals = bool("Cherry Petals", false, "Pink petals drifting down");
    private final BoolSetting embers = bool("Embers", false, "Warm embers rising from the ground");
    private final BoolSetting ash = bool("Ash Fall", false, "Grey ash slowly falling");
    private final BoolSetting spores = bool("Spores", false, "Teal and red spores floating around");
    private final BoolSetting souls = bool("Soul Wisps", false, "Blue wisps rising like ghosts");
    private final BoolSetting magic = bool("Magic Glyphs", false, "Enchanting-table glyphs flying around you");
    private final BoolSetting mist = bool("Mist", false, "Low white mist near the ground");
    private final BoolSetting dragon = bool("Dragon Breath", false, "Purple haze hugging the ground");
    private final BoolSetting voidDust = bool("Void Dust", false, "Purple portal dust drifting through the air");

    public Ambiance() {
        super("Ambiance", Category.VFX, "Atmospheric particles around you: fireflies, snow, embers and more");
    }

    private static double rnd() {
        return ThreadLocalRandom.current().nextDouble();
    }

    private static double spread(double range) {
        return (rnd() * 2.0 - 1.0) * range;
    }

    private int count(double rate) {
        double v = rate * intensity.get();
        int n = (int) v;
        if (rnd() < v - n) n++;
        return n;
    }

    private void spawn(ParticleEffect effect, double x, double y, double z, double vx, double vy, double vz) {
        mc.world.addParticle(effect, x, y, z, vx, vy, vz);
    }

    @Override
    public void onTick() {
        if (mc.world == null || mc.player == null) return;

        double px = mc.player.getX();
        double py = mc.player.getY();
        double pz = mc.player.getZ();
        double r = radius.get();
        boolean sky = !outdoorsOnly.get() || mc.world.isSkyVisible(mc.player.getBlockPos());

        if (fireflies.get()) {
            int n = count(0.35);
            for (int i = 0; i < n; i++) {
                spawn(ParticleTypes.GLOW, px + spread(r), py - 0.5 + rnd() * 3.5, pz + spread(r),
                        spread(0.01), spread(0.01), spread(0.01));
            }
        }
        if (sparkles.get()) {
            int n = count(0.5);
            for (int i = 0; i < n; i++) {
                spawn(ParticleTypes.END_ROD, px + spread(r), py + rnd() * 4.0, pz + spread(r),
                        spread(0.004), 0.01 + rnd() * 0.02, spread(0.004));
            }
        }
        if (snow.get() && sky) {
            int n = count(2.0);
            for (int i = 0; i < n; i++) {
                spawn(ParticleTypes.SNOWFLAKE, px + spread(r), py + 6.0 + rnd() * 5.0, pz + spread(r),
                        spread(0.02), -0.1, spread(0.02));
            }
        }
        if (petals.get() && sky) {
            int n = count(0.8);
            for (int i = 0; i < n; i++) {
                spawn(ParticleTypes.CHERRY_LEAVES, px + spread(r), py + 5.0 + rnd() * 6.0, pz + spread(r),
                        spread(0.03), -0.02, spread(0.03));
            }
        }
        if (embers.get()) {
            int n = count(0.6);
            for (int i = 0; i < n; i++) {
                spawn(ParticleTypes.FLAME, px + spread(r), py + rnd() * 2.0, pz + spread(r),
                        spread(0.01), 0.04 + rnd() * 0.04, spread(0.01));
            }
        }
        if (ash.get() && sky) {
            int n = count(1.5);
            for (int i = 0; i < n; i++) {
                spawn(ParticleTypes.ASH, px + spread(r), py + 2.0 + rnd() * 6.0, pz + spread(r),
                        spread(0.01), -0.02, spread(0.01));
            }
            int w = count(0.4);
            for (int i = 0; i < w; i++) {
                spawn(ParticleTypes.WHITE_ASH, px + spread(r), py + 2.0 + rnd() * 6.0, pz + spread(r),
                        spread(0.01), -0.02, spread(0.01));
            }
        }
        if (spores.get()) {
            int n = count(0.8);
            for (int i = 0; i < n; i++) {
                spawn(ParticleTypes.WARPED_SPORE, px + spread(r), py + rnd() * 3.0, pz + spread(r),
                        spread(0.01), -0.01, spread(0.01));
            }
            int c = count(0.5);
            for (int i = 0; i < c; i++) {
                spawn(ParticleTypes.CRIMSON_SPORE, px + spread(r), py + rnd() * 3.0, pz + spread(r),
                        spread(0.01), -0.01, spread(0.01));
            }
        }
        if (souls.get()) {
            int n = count(0.25);
            for (int i = 0; i < n; i++) {
                spawn(ParticleTypes.SOUL, px + spread(r), py + rnd() * 2.0, pz + spread(r), 0.0, 0.03, 0.0);
            }
            int f = count(0.15);
            for (int i = 0; i < f; i++) {
                spawn(ParticleTypes.SOUL_FIRE_FLAME, px + spread(r), py + rnd() * 2.0, pz + spread(r), 0.0, 0.03, 0.0);
            }
        }
        if (magic.get()) {
            int n = count(1.5);
            for (int i = 0; i < n; i++) {
                double sx = px + spread(3.0);
                double sy = py + 0.5 + rnd() * 2.5;
                double sz = pz + spread(3.0);
                spawn(ParticleTypes.ENCHANT, sx, sy, sz, px - sx, py + 1.5 - sy, pz - sz);
            }
        }
        if (mist.get()) {
            int n = count(0.2);
            for (int i = 0; i < n; i++) {
                spawn(ParticleTypes.CLOUD, px + spread(r), py - 0.5 + rnd() * 1.0, pz + spread(r),
                        spread(0.005), 0.0, spread(0.005));
            }
        }
        if (dragon.get()) {
            int n = count(0.8);
            for (int i = 0; i < n; i++) {
                spawn(ParticleTypes.DRAGON_BREATH, px + spread(r), py - 0.3 + rnd() * 1.0, pz + spread(r),
                        spread(0.01), 0.01, spread(0.01));
            }
        }
        if (voidDust.get()) {
            int n = count(1.2);
            for (int i = 0; i < n; i++) {
                spawn(ParticleTypes.PORTAL, px + spread(r), py + rnd() * 3.0, pz + spread(r),
                        spread(0.5), spread(0.5), spread(0.5));
            }
        }
    }
}
