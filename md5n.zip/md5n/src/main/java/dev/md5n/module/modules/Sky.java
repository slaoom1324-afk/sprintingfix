package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.ModeSetting;
import dev.md5n.setting.NumSetting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Sky extends Module {
    private final ModeSetting style = mode("Style", "Sunset",
            "Static: Sunset, Twilight, Blood, Emerald, Void  |  Animated: Rainbow, Aurora, Pulse, Lava, Dream",
            "Sunset", "Twilight", "Blood", "Emerald", "Void",
            "Rainbow", "Aurora", "Pulse", "Lava", "Dream");
    private final NumSetting speed = num("Speed", 1.0, 0.2, 3.0, 0.1, "Speed of the animated styles");
    private final NumSetting brightness = num("Brightness", 1.0, 0.3, 1.5, 0.05, "Overall sky brightness");
    private final BoolSetting dayNight = bool("Day/Night Blend", false, "Dim the sky at night like vanilla");

    public Sky() {
        super("Sky", Category.VFX, "Custom sky colors: 5 static and 5 animated styles (overworld)");
    }

    /** يستدعيها الـ Mixin: ياخذ لون السماء الأصلي ويرجع لون الستايل المختار. */
    public Vec3d apply(Vec3d base) {
        double t = (System.currentTimeMillis() % 7_200_000L) / 1000.0 * speed.get();
        double[] c = color(style.get(), t);

        double f = brightness.get();
        if (dayNight.get()) {
            double day = clamp01((base.x + base.y + base.z) / 2.0);
            f *= 0.12 + 0.88 * day;
        }
        return new Vec3d(clamp01(c[0] * f), clamp01(c[1] * f), clamp01(c[2] * f));
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }

    private static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    private static double[] mix(double[] a, double[] b, double t) {
        return new double[]{lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)};
    }

    private static double[] hsv(double h, double s, double v) {
        int rgb = MathHelper.hsvToRgb((float) h, (float) s, (float) v);
        return new double[]{((rgb >> 16) & 0xFF) / 255.0, ((rgb >> 8) & 0xFF) / 255.0, (rgb & 0xFF) / 255.0};
    }

    private static double[] color(String name, double t) {
        switch (name) {
            // ----- ثابتة -----
            case "Twilight":
                return new double[]{0.36, 0.26, 0.70};
            case "Blood":
                return new double[]{0.58, 0.05, 0.07};
            case "Emerald":
                return new double[]{0.22, 0.82, 0.55};
            case "Void":
                return new double[]{0.03, 0.02, 0.10};

            // ----- متحركة -----
            case "Rainbow":
                return hsv((t / 20.0) % 1.0, 0.55, 1.0);
            case "Aurora": {
                double a = 0.5 + 0.5 * Math.sin(t * 0.5);
                double w = 0.08 * Math.sin(t * 1.3);
                return new double[]{lerp(0.20, 0.55, a) + w, lerp(0.95, 0.25, a) + w, lerp(0.55, 0.95, a) + w};
            }
            case "Pulse": {
                double k = 0.55 + 0.45 * (0.5 + 0.5 * Math.sin(t * 1.5));
                return new double[]{0.25 * k, 0.90 * k, 1.00 * k};
            }
            case "Lava": {
                double m = 0.5 + 0.25 * Math.sin(t * 0.9) + 0.25 * Math.sin(t * 2.3 + 1.0);
                return new double[]{lerp(0.35, 1.00, m), lerp(0.03, 0.38, m), lerp(0.02, 0.05, m)};
            }
            case "Dream": {
                double p = (t / 12.0) % 3.0;
                double[] pink = {0.95, 0.50, 0.80};
                double[] blue = {0.45, 0.65, 1.00};
                double[] lavender = {0.70, 0.50, 0.95};
                if (p < 1.0) return mix(pink, blue, p);
                if (p < 2.0) return mix(blue, lavender, p - 1.0);
                return mix(lavender, pink, p - 2.0);
            }

            // Sunset (الافتراضي)
            default:
                return new double[]{1.00, 0.52, 0.32};
        }
    }
}
