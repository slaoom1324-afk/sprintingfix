package dev.md5n.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

public final class Fx {
    private Fx() {}

    /** جسيمة غبار بلون RGB. */
    public static void dust(int rgb, float scale, double x, double y, double z, double vx, double vy, double vz) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        mc.world.addParticle(new DustParticleEffect(rgb & 0xFFFFFF, scale), x, y, z, vx, vy, vz);
    }

    public static void puff(double x, double y, double z, double vx, double vy, double vz) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        mc.world.addParticle(ParticleTypes.CLOUD, x, y, z, vx, vy, vz);
    }

    /** تأثير VFX فوق الكوزمتك: جسيمات ماينكرافت الأصلية. */
    public static void vfx(String type, double x, double y, double z, double vx, double vy, double vz) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        ParticleEffect p;
        switch (type) {
            case "Glow": p = ParticleTypes.GLOW; break;
            case "Flame": p = ParticleTypes.FLAME; break;
            case "Soul": p = ParticleTypes.SOUL_FIRE_FLAME; break;
            case "Magic": p = ParticleTypes.ENCHANT; break;
            case "Electric": p = ParticleTypes.ELECTRIC_SPARK; break;
            case "Snow": p = ParticleTypes.SNOWFLAKE; break;
            case "Petals": p = ParticleTypes.CHERRY_LEAVES; break;
            case "Portal": p = ParticleTypes.PORTAL; break;
            default: p = ParticleTypes.END_ROD; break;
        }
        mc.world.addParticle(p, x, y, z, vx, vy, vz);
    }
}
