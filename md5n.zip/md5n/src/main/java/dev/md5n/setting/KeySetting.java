package dev.md5n.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import net.minecraft.client.util.InputUtil;

/** خيار قيمته مفتاح (مثل مفتاح القفل). المود نفسه يسأل: انضغط ولا لا؟ */
public class KeySetting extends Setting {
    public KeySetting(String name, int def, String description) {
        super(name, description);
        setKey(def);
    }

    /** يرجع true مرة وحدة عند بداية الضغطة. */
    public boolean consumePress(long window) {
        int k = getKey();
        if (k < 0) return false;
        boolean down = InputUtil.isKeyPressed(window, k);
        boolean fire = down && !isKeyDown();
        setKeyDown(down);
        return fire;
    }

    @Override
    public JsonElement toJson() { return new JsonPrimitive(getKey()); }

    @Override
    public void fromJson(JsonElement element) { setKey(element.getAsInt()); }
}
